import { useState, useEffect, useRef } from 'react';
import './App.css';

function App() {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY;
      const height = document.documentElement.scrollHeight - window.innerHeight;
      setScrollProgress((scrolled / height) * 100);
    };

    const handleMouseMove = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('.fade-up').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="app">
      {/* Custom Cursor */}
      <div
        className={`cursor ${isHovering ? 'hover' : ''}`}
        style={{ left: cursorPos.x - 10, top: cursorPos.y - 10 }}
      />
      <div
        className="cursor-dot"
        style={{ left: cursorPos.x - 3, top: cursorPos.y - 3 }}
      />

      {/* Scroll Progress */}
      <div className="scroll-progress" style={{ width: `${scrollProgress}%` }} />

      {/* Grain Texture */}
      <div className="grain" />

      {/* Navigation */}
      <nav>
        <div className="logo">HASSAN</div>
        <ul className="nav-links">
          {['about', 'services', 'process', 'testimonials', 'faq', 'contact'].map((item) => (
            <li key={item}>
              <button onClick={() => scrollToSection(item)}>{item.charAt(0).toUpperCase() + item.slice(1)}</button>
            </li>
          ))}
        </ul>
      </nav>

      {/* Hero Section */}
      <section className="hero" id="hero">
        <div className="hero-bg" />
        <div className="float-element float-1" />
        <div className="float-element float-2" />
        <div className="float-element float-3" />

        <div className="hero-content fade-up">
          <div className="hero-badge">
            <span>Available for Projects</span>
          </div>
          <h1>
            I Turn Your <span className="gradient-text">Ad Spend</span>
            <br />
            Into <span className="gradient-text">Real Sales</span>
          </h1>
          <p>
            Expert media buyer specializing in converting advertising budgets into measurable business results.
            I help businessmen scale their revenue through data-driven campaigns.
          </p>
          <div className="hero-cta">
            <button className="btn btn-primary" onClick={() => scrollToSection('contact')}>
              Message Me
            </button>
            <button className="btn btn-secondary" onClick={() => scrollToSection('services')}>
              View Services
            </button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about">
        <div className="about">
          <div className="about-image fade-up">
            <div className="about-image-wrapper">
              <div className="about-image-inner">H</div>
            </div>
          </div>
          <div className="about-content fade-up">
            <h2>Your Growth Partner in Digital Advertising</h2>
            <p>
              With years of experience in media buying, I've helped numerous businesses
              maximize their advertising ROI. My approach combines data analysis with
              creative optimization to deliver campaigns that not only get clicks but convert.
            </p>
            <p>
              I specialize in targeting businessmen and decision-makers who understand
              that quality leads are worth more than quantity. Every dollar you spend
              should work harder than the last.
            </p>
            <div className="stats">
              <div className="stat">
                <div className="stat-number">5+</div>
                <div className="stat-label">Years Experience</div>
              </div>
              <div className="stat">
                <div className="stat-number">200%</div>
                <div className="stat-label">Avg. ROAS</div>
              </div>
              <div className="stat">
                <div className="stat-number">50+</div>
                <div className="stat-label">Clients Served</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services">
        <div className="section-header fade-up">
          <div className="section-tag">What I Do</div>
          <h2 className="section-title">Services Built for Results</h2>
          <p className="section-subtitle">
            Comprehensive media buying solutions designed to transform your ad spend into measurable sales.
          </p>
        </div>

        <div className="services-grid">
          {[
            {
              icon: '🎯',
              title: 'Campaign Strategy',
              desc: 'Custom advertising strategies tailored to your business goals. I analyze your market, competitors, and audience to create campaigns that deliver results.',
            },
            {
              icon: '📈',
              title: 'Conversion Optimization',
              desc: 'Continuous testing and optimization to improve your campaign performance. I don\'t just run ads—I refine them until they convert.',
            },
            {
              icon: '👥',
              title: 'Targeted Audience Research',
              desc: 'Deep-dive audience analysis to reach the right decision-makers. I find the businessmen most likely to convert into paying customers.',
            },
            {
              icon: '📊',
              title: 'Analytics & Reporting',
              desc: 'Detailed performance reports with actionable insights. Know exactly where your money goes and what returns you\'re getting.',
            },
          ].map((service, index) => (
            <div className="service-card fade-up" key={index}>
              <div className="service-icon">{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Why Work With Me */}
      <section id="why">
        <div className="section-header fade-up">
          <div className="section-tag">Why Choose Me</div>
          <h2 className="section-title">The Hassan's Advantage</h2>
          <p className="section-subtitle">
            Working with me means partnering with someone who treats your budget like their own.
          </p>
        </div>

        <div className="why-grid">
          {[
            { icon: '✓', title: 'Results-First Approach', desc: 'Every decision is driven by your ROI, not vanity metrics' },
            { icon: '⏱', title: 'Fast Turnaround', desc: 'Campaigns launched within 48 hours of getting started' },
            { icon: '🛡', title: 'Transparent Reporting', desc: 'Real-time dashboards and weekly performance reviews' },
            { icon: '💬', title: 'Direct Communication', desc: 'No account managers—you work directly with me' },
          ].map((item, index) => (
            <div className="why-card fade-up" key={index}>
              <div className="why-icon">{item.icon}</div>
              <h3>{item.title}</h3>
              <p>{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Process Section */}
      <section id="process">
        <div className="section-header fade-up">
          <div className="section-tag">How It Works</div>
          <h2 className="section-title">My Proven Process</h2>
          <p className="section-subtitle">
            A systematic approach that delivers consistent results every time.
          </p>
        </div>

        <div className="process-timeline">
          {[
            { step: '1', title: 'Discovery Call', desc: 'We discuss your business goals, target audience, and current advertising challenges to understand exactly what success looks like for you.' },
            { step: '2', title: 'Strategy Development', desc: 'I create a custom media buying strategy based on your budget, timeline, and target market—focused on reaching businessmen who convert.' },
            { step: '3', title: 'Campaign Launch', desc: 'Your campaigns go live with carefully crafted ad creative, precise targeting, and conversion tracking set up from day one.' },
            { step: '4', title: 'Optimize & Scale', desc: 'Continuous testing and optimization to improve performance. Once we find what works, we scale it profitably.' },
          ].map((item, index) => (
            <div className="process-step fade-up" key={index}>
              <div className="process-number">{item.step}</div>
              <div className="process-content">
                <h3>{item.title}</h3>
                <p>{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials">
        <div className="section-header fade-up">
          <div className="section-tag">Client Success</div>
          <h2 className="section-title">What Clients Say</h2>
          <p className="section-subtitle">Real results from real businesses.</p>
        </div>

        <div className="testimonials-grid">
          {[
            { text: 'Hassan transformed our ad campaigns completely. We went from burning budget on unqualified leads to consistently getting appointments with decision-makers. Our sales team has never been happier.', name: 'Ahmed M.', role: 'CEO, Tech Solutions Inc.' },
            { text: 'The ROI speaks for itself—3x what we were getting before. Hassan doesn\'t just run ads; he understands business. Every campaign decision is backed by data and logic.', name: 'Sarah K.', role: 'Founder, FinanceHub' },
            { text: 'Finally found a media buyer who delivers on promises. Our customer acquisition cost dropped by 40% while lead quality improved dramatically. Worth every penny.', name: 'Robert J.', role: 'Director, GrowthLabs' },
          ].map((testimonial, index) => (
            <div className="testimonial-card fade-up" key={index}>
              <p className="testimonial-text">"{testimonial.text}"</p>
              <div className="testimonial-author">
                <div className="testimonial-avatar">{testimonial.name.split(' ').map(n => n[0]).join('')}</div>
                <div className="testimonial-info">
                  <h4>{testimonial.name}</h4>
                  <span>{testimonial.role}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq">
        <div className="section-header fade-up">
          <div className="section-tag">FAQ</div>
          <h2 className="section-title">Common Questions</h2>
          <p className="section-subtitle">Quick answers to help you make a decision.</p>
        </div>

        <div className="faq-list">
          {[
            { q: 'What platforms do you advertise on?', a: 'I specialize in Meta (Facebook & Instagram), LinkedIn, and Google Ads. The best platform depends on your target audience and goals—I recommend the right fit for your specific situation.' },
            { q: 'What\'s your minimum ad spend?', a: 'I typically work with businesses spending at least $2,000/month on ads. This ensures the data we collect is statistically significant and allows for proper optimization.' },
            { q: 'How do you track results?', a: 'I set up comprehensive tracking including pixel installation, conversion tracking, and custom dashboards. You\'ll see real-time data on leads, sales, and ROI.' },
            { q: 'How long until I see results?', a: 'Most clients see initial results within 2-3 weeks. Significant improvements typically occur within 4-6 weeks as we optimize based on real data.' },
          ].map((faq, index) => (
            <div className={`faq-item fade-up ${openFaq === index ? 'active' : ''}`} key={index}>
              <button className="faq-question" onClick={() => toggleFaq(index)}>
                {faq.q}
                <span className="faq-icon">{openFaq === index ? '−' : '+'}</span>
              </button>
              <div className="faq-answer" style={{ maxHeight: openFaq === index ? '300px' : '0' }}>
                <p>{faq.a}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta" id="contact">
        <div className="cta-bg" />
        <div className="cta-content fade-up">
          <h2>Ready to Convert Your Ad Spend <br />Into Real Sales?</h2>
          <p>
            Let's discuss how I can help you reach more businessmen
            and grow your revenue with data-driven advertising.
          </p>
          <a href="https://hassanpk0.gumroad.com/l/yqaxxm" className="btn btn-primary" target="_blank" rel="noopener noreferrer">
            Message Me
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer>
        <p>
          © 2024 Hassan | Media Buyer |
          <a href="https://hassanpk0.gumroad.com/l/yqaxxm" target="_blank" rel="noopener noreferrer"> Get in Touch</a>
        </p>
      </footer>
    </div>
  );
}

export default App;